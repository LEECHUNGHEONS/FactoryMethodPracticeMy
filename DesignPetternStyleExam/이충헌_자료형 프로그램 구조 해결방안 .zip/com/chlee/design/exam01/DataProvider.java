package com.chlee.design.exam01;

import java.util.Collection;

public interface DataProvider<T> {
	Collection<T> getData();

}
