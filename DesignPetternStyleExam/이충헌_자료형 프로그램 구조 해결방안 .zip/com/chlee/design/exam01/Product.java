package com.chlee.design.exam01;

//프로덕트입니다.
public interface Product {
	void printInfo();

}
